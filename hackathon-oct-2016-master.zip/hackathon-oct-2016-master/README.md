# hackathon-oct-2016
### Our team replicated four Materialize.css components in pure CSS

1. Dropdown: <a href="http://materializecss.com/dropdown.html">http://materializecss.com/dropdown.html</a>
2. Modal: <a href="http://materializecss.com/modals.html">http://materializecss.com/modals.html</a>
3. Wave: <a href="http://materializecss.com/waves.html">http://materializecss.com/waves.html</a>
4. Collapsible: <a href="http://materializecss.com/collapsible.html">http://materializecss.com/collapsible.html</a>

Demo: [https://frankstepanski.github.io/hackathon-oct-2016](https://frankstepanski.github.io/hackathon-oct-2016)<br>
(CSS version of: [http://www.jqueryscript.net/demo/One-Page-Scrolling-Navigation-with-jQuery-CSS3/](http://www.jqueryscript.net/demo/One-Page-Scrolling-Navigation-with-jQuery-CSS3/))

### Team Members
* Mentor: [Gabriele Romeo](https://github.com/GabrieleRomeo)
* Mentee: Frank Stepanski
